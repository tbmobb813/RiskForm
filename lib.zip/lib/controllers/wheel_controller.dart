class WheelController {
  // placeholder for wheel strategy operations
}
