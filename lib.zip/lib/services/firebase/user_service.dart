class UserService {
  // placeholder for user-specific firestore operations
}
