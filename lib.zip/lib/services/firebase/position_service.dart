class PositionService {
  // placeholder for position persistence
}
