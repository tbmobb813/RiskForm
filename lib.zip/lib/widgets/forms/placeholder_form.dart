import 'package:flutter/material.dart';

class PlaceholderForm extends StatelessWidget {
  const PlaceholderForm({super.key});

  @override
  Widget build(BuildContext context) {
    return const SizedBox.shrink();
  }
}
