class RiskProfile {
  final String id;
  final double maxRiskPercent;

  RiskProfile({required this.id, required this.maxRiskPercent});
}
