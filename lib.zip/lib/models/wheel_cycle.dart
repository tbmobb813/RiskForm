class WheelCycle {
  final String id;
  final DateTime startedAt;

  WheelCycle({required this.id, required this.startedAt});
}
