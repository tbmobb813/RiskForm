abstract class StrategyEngineInterface {
  Future<double> estimateRisk(Map<String, dynamic> inputs);
}
