class DashboardState {
  // placeholder for dashboard UI state
}
