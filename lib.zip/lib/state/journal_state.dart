class JournalState {
  // placeholder for journal state
}
