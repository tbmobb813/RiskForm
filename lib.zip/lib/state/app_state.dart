class AppState {
  // placeholder for global app state
}
